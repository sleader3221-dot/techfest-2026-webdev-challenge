const $ = id => document.getElementById(id);
const DEFAULT_APPLIANCES = [
  {name:"Fan", watts:75, hours:8, qty:1},
  {name:"Air conditioner", watts:1200, hours:2, qty:1},
  {name:"Geyser", watts:2000, hours:0.5, qty:1},
  {name:"Refrigerator", watts:150, hours:8, qty:1},
  {name:"LED lights", watts:40, hours:5, qty:1},
  {name:"Laptop", watts:60, hours:5, qty:1},
  {name:"Television", watts:100, hours:2, qty:1}
];
const CATEGORIES = ["Commute","Electricity","Diet","Flights","Waste"];
const COLORS = ["#4c9666","#d6a65c","#86a9a0","#8a83b7","#d28b67"];
const STORAGE_KEY = "carboncut_dashboard_v3";
const HISTORY_KEY = "carboncut_monthly_history_v1";
let appliances = DEFAULT_APPLIANCES.map(x=>({...x}));
let chart = null;
let current = null;
let applianceReductions = {};

function safeNumber(id, fallback=0) {
  const n = Number($(id)?.value);
  return Number.isFinite(n) ? Math.max(0,n) : fallback;
}
function clamp(n,min,max){return Math.min(max,Math.max(min,n));}
function money(n){return "₹"+Math.round(n).toLocaleString("en-IN");}
function fmt(n,d=1){return Number(n||0).toFixed(d);}
function energyFor(a,hours=a.hours){
  return (a.watts * hours * 30 * a.qty) / 1000;
}
const VEHICLE_FACTORS = {
  walk: 0, bus: 0.08,
  bike_petrol_150: 0.045, bike_petrol_large: 0.07, bike_electric: 0.025,
  car_petrol: 0.17, car_diesel: 0.18, car_cng: 0.14, car_electric: 0.05
};
function commuteFactor(){
  const mode = $("commute-mode").value;
  if(mode === "walk") return VEHICLE_FACTORS.walk;
  if(mode === "bus") return VEHICLE_FACTORS.bus;
  const type = $("vehicle-type").value;
  return VEHICLE_FACTORS[type] ?? VEHICLE_FACTORS.bike_petrol_150;
}
function updateVehicleOptions(){
  const mode = $("commute-mode").value;
  const wrap = $("vehicle-type-wrap");
  const select = $("vehicle-type");
  if(mode === "walk" || mode === "bus") { wrap.classList.add("hidden"); return; }
  wrap.classList.remove("hidden");
  const allowed = mode === "car" ? ["car_petrol","car_diesel","car_cng","car_electric"] : ["bike_petrol_150","bike_petrol_large","bike_electric"];
  if(!allowed.includes(select.value)) select.value = allowed[0];
  [...select.options].forEach(o => { o.hidden = !allowed.includes(o.value); });
}
function readInputs(){
  const people = Math.max(1,Math.floor(safeNumber("people",1)));
  const tariff = safeNumber("tariff",7);
  const standby = $("standby").checked ? 7.2 : 0;
  const applianceKwh = appliances.reduce((s,a)=>s+energyFor(a),0);
  const householdKwh = applianceKwh + standby;
  const electricityPerPerson = householdKwh * 0.7 / people;
  const commute = commuteFactor() * safeNumber("commute-km") * 30;
  const diet = safeNumber("diet");
  const flights = safeNumber("flights") * 150 / 12;
  const waste = safeNumber("waste");
  const categories = [commute,electricityPerPerson,diet,flights,waste];
  const total = categories.reduce((a,b)=>a+b,0);
  const biggestIndex = categories.indexOf(Math.max(...categories));
  const biggestAppliance = appliances.map(a=>({...a,kwh:energyFor(a)})).sort((a,b)=>b.kwh-a.kwh)[0] || null;
  return {people,tariff,householdKwh,applianceKwh,electricityPerPerson,commute,diet,flights,waste,categories,total,biggestIndex,biggestCategory:CATEGORIES[biggestIndex],biggestAppliance,bill:householdKwh*tariff};
}
function renderAppliances(){
  $("appliance-list").innerHTML = appliances.map((a,i)=>`
    <div class="appliance-row">
      <div class="appliance-name"><strong>${escapeHtml(a.name)}</strong><small>${a.watts} W · Qty ${a.qty}</small></div>
      <input type="range" min="0" max="24" step="0.5" value="${a.hours}" data-hours="${i}" aria-label="${escapeHtml(a.name)} hours per day">
      <span class="usage-number">${fmt(a.hours,1)} h/day</span>
      <button class="remove-appliance" data-remove="${i}" title="Remove ${escapeHtml(a.name)}" aria-label="Remove ${escapeHtml(a.name)}">×</button>
    </div>`).join("");
}
function escapeHtml(str){return String(str).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function update(){
  current = readInputs();
  const d = current;
  $("total-carbon").textContent = Math.round(d.total).toLocaleString("en-IN");
  $("per-person").textContent = `Per person · ${d.people} ${d.people===1?"person":"people"} in household`;
  $("total-kwh").textContent = fmt(d.householdKwh,1);
  $("total-bill").textContent = money(d.bill);
  $("biggest-category").textContent = d.biggestCategory;
  $("biggest-detail").textContent = `${fmt(d.categories[d.biggestIndex],1)} kg CO₂e / person`;
  $("audit-kwh").textContent = fmt(d.householdKwh,1);
  $("audit-hog").textContent = d.biggestAppliance ? d.biggestAppliance.name : "—";
  $("audit-carbon").textContent = Math.round(d.total).toLocaleString("en-IN");
  $("audit-electric-carbon").textContent = `${fmt(d.electricityPerPerson,1)} kg`;
  $("audit-other-carbon").textContent = `${fmt(d.commute+d.diet+d.flights+d.waste,1)} kg`;
  $("audit-bill").textContent = money(d.bill);
  const goal = 20;
  $("goal-summary").textContent = `${goal}% target`;
  const baseline = Math.max(d.total,1);
  const simulated = getScenario(false).total;
  const reduction = Math.max(0,d.total-simulated);
  const progress = clamp(reduction/(baseline*goal/100)*100,0,100);
  $("goal-progress").style.width = `${progress}%`;
  $("goal-percent").textContent = `${Math.round(progress)}%`;
  updateImpactTree(d.total);
  const insights = [
    "Your commute is the largest estimated source. Try comparing public transport or lower-emission travel options in the simulator.",
    d.biggestAppliance ? `${d.biggestAppliance.name} is your highest-use appliance at ${fmt(d.biggestAppliance.kwh,1)} kWh/month. Try reducing its daily usage in the simulator.` : "Add appliances to discover your biggest energy user.",
    "Your selected diet pattern is a major part of your estimated footprint. Compare a lower-impact food pattern in the simulator.",
    "Your flight estimate is a significant contributor. Consider comparing fewer flights or alternative travel where practical.",
    "Waste is a notable contributor in your estimate. Reducing food waste and improving segregation can help."
  ];
  $("insight-text").textContent = insights[d.biggestIndex];
  $("car-equivalent").textContent = `${Math.round(d.total/0.17).toLocaleString("en-IN")} km`;
  $("tree-equivalent").textContent = `${fmt(d.total*12/21,1)} trees`;
  renderChart(d.categories);
  renderCostBreakdown(d);
  renderRecommendations(d);
  renderAchievements(d);
  renderMonthlyComparison(d);
  renderApplianceScenarioControls();
  renderScenario();
  save();
}

function updateImpactTree(monthlyEmissions) {
  const crown = $("tree-crown");
  const highlights = $("tree-highlights");
  const branches = $("tree-branches");
  const dryLeaves = $("tree-dry-leaves");
  const svg = document.querySelector(".tree-svg");

  let state;
  if (monthlyEmissions < 100) state = "healthy";
  else if (monthlyEmissions < 180) state = "moderate";
  else state = "dry";

  const looks = {
    healthy: {
      title: "Your tree is thriving!",
      message: "Your estimated footprint is in the lower range. Keep up these habits.",
      leaves: "#2F9B68", highlights: "#D6E9B7", trunk: "#8B5A36",
      scale: "scale(1)", opacity: "1", dryOpacity: "0"
    },
    moderate: {
      title: "Your tree is doing alright.",
      message: "Your footprint is moderate. A few small changes can help it flourish.",
      leaves: "#8DAD55", highlights: "#DCE6A7", trunk: "#8B6842",
      scale: "scale(.96)", opacity: ".96", dryOpacity: "0"
    },
    dry: {
      title: "Your tree is drying out.",
      message: "Your estimated footprint is high. Try reducing your biggest sources of emissions.",
      leaves: "#A97845", highlights: "#D8B77B", trunk: "#76513A",
      scale: "scale(.84)", opacity: ".88", dryOpacity: ".95"
    }
  }[state];

  if (crown) {
    crown.setAttribute("fill", looks.leaves);
    crown.style.transformBox = "fill-box";
    crown.style.transformOrigin = "center bottom";
    crown.style.transform = looks.scale;
    crown.style.opacity = looks.opacity;
  }
  if (highlights) highlights.setAttribute("fill", looks.highlights);
  if (branches) branches.setAttribute("stroke", looks.trunk);
  if (dryLeaves) dryLeaves.setAttribute("opacity", looks.dryOpacity);
  if (svg) svg.setAttribute("aria-label", `Impact tree status: ${state}. ${looks.title}`);
  $("tree-message").textContent = looks.title;
  $("tree-submessage").textContent = looks.message;
}

function renderChart(values){
  const labels = CATEGORIES;
  if(window.Chart){
    if(!chart){
      chart = new Chart($("emissions-chart"),{
        type:"doughnut",
        data:{labels,datasets:[{data:values,backgroundColor:COLORS,borderWidth:3,borderColor:"#fff",hoverOffset:5}]},
        options:{responsive:true,maintainAspectRatio:false,cutout:"69%",plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>`${c.label}: ${fmt(c.raw,1)} kg CO₂e`}}}}
      });
    }else{chart.data.datasets[0].data=values;chart.update("none");}
  }else{
    $("chart-legend").innerHTML = "<span class='helper-note'>Chart requires an internet connection to load Chart.js.</span>";
  }
  $("chart-legend").innerHTML = labels.map((l,i)=>`<span class="legend-item"><i class="legend-dot" style="background:${COLORS[i]}"></i>${l}</span>`).join("");
}
function renderCostBreakdown(d){
  const host = $("appliance-costs");
  if(!host) return;
  if(!appliances.length){host.innerHTML="<p class='helper-note'>Add appliances to see their estimated monthly costs.</p>";return;}
  const rows = appliances.map(a=>({name:a.name,kwh:energyFor(a),cost:energyFor(a)*d.tariff})).sort((a,b)=>b.cost-a.cost);
  const max = Math.max(...rows.map(x=>x.cost),1);
  host.innerHTML = rows.map(x=>`
    <div class="cost-item">
      <span>${escapeHtml(x.name)}</span>
      <div class="cost-meter" title="${fmt(x.kwh,1)} kWh/month"><i style="width:${x.cost/max*100}%"></i></div>
      <strong>${money(x.cost)}</strong>
    </div>`).join("");
}
function renderRecommendations(d){
  const host=$("recommendations");
  if(!host)return;
  const ideas=[];
  const top=d.biggestAppliance;
  if(d.biggestIndex===1 && top){
    const savedKwh=top.watts*top.qty*Math.min(1,top.hours)*30/1000;
    ideas.push(["ϟ",`Review ${top.name} usage`,`It is your highest-use appliance (${fmt(top.kwh,1)} kWh/month). Reducing it by 1 hour/day could save up to ${fmt(savedKwh,1)} kWh/month and ${money(savedKwh*d.tariff)} on the estimated bill, if used for at least that hour daily.`]);
  }
  if(d.biggestIndex===0){
    ideas.push(["↗","Try a lower-emission commute",`Commute is your largest estimated category (${fmt(d.commute,1)} kg/month). Compare bus or cycling in the What-if Simulator where practical.`]);
  }
  if(d.biggestIndex===2){
    ideas.push(["♧","Compare your food pattern","Diet is your largest estimated category. Try the lower-impact diet option in the simulator and review the estimated difference."]);
  }
  if(d.biggestIndex===3){
    ideas.push(["✈","Review flight frequency","Flights are your largest estimated category. Where practical, consider combining trips or choosing alternatives for shorter journeys."]);
  }
  if(d.biggestIndex===4){
    ideas.push(["♻","Reduce and sort household waste","Waste is your largest estimated category. Try preventing food waste, reusing items and separating recyclable materials."]);
  }
  if(top && top.kwh>0 && (!ideas.length || d.biggestIndex!==1)){
    ideas.push(["⌂",`Your top appliance is ${top.name}`,`It uses ${fmt(top.kwh,1)} kWh/month. Check its hours and switch it off when not needed.`]);
  }
  ideas.push(["₹","Check your electricity tariff",`Your current estimate uses ${money(d.tariff)} per kWh. Enter the tariff from your latest bill for a more useful cost estimate.`]);
  host.innerHTML=ideas.slice(0,3).map(x=>`<div class="recommendation-item"><span class="rec-icon">${x[0]}</span><div><strong>${escapeHtml(x[1])}</strong><p>${escapeHtml(x[2])}</p></div></div>`).join("");
}
function renderAchievements(d){
  const host=$("achievement-badges");if(!host)return;
  const scenario=getScenario();
  const items=[
    ["🌱","Audit starter","Opened and completed your footprint estimate",true],
    ["⚡","Energy explorer","Added or reviewed appliance-level energy use",appliances.length>0],
    ["💡","Scenario thinker","Tested a change that lowers estimated emissions",scenario.saving>0.01],
    ["🌍","20% challenge","Scenario reduces your estimate by at least 20%",d.total>0 && scenario.saving/d.total>=.2]
  ];
  host.innerHTML=items.map(x=>`<div class="achievement ${x[3]?'unlocked':''}"><div class="badge-icon">${x[0]}</div><strong>${x[1]}</strong><small>${x[3]?'Unlocked':x[2]}</small></div>`).join("");
}
function renderMonthlyComparison(d){
  const host=$("monthly-comparison");if(!host)return;
  const now=new Date();
  const key=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
  let history={};
  try{history=JSON.parse(localStorage.getItem(HISTORY_KEY)||"{}");}catch(e){history={};}
  const previousDate=new Date(now.getFullYear(),now.getMonth()-1,1);
  const previousKey=`${previousDate.getFullYear()}-${String(previousDate.getMonth()+1).padStart(2,'0')}`;
  const previous=history[previousKey];
  if(previous && Number.isFinite(previous.total)){
    const diff=d.total-previous.total;
    const pct=previous.total>0?Math.abs(diff)/previous.total*100:0;
    host.innerHTML=`<strong>${previousKey} vs ${key}</strong><div class="monthly-delta ${diff<=0?'down':'up'}">${diff<=0?'↓':'↑'} ${fmt(pct,1)}%</div><p>${diff<=0?'Your current estimate is lower':'Your current estimate is higher'} than the last saved month by ${fmt(Math.abs(diff),1)} kg CO₂e per person. Previous: ${fmt(previous.total,1)} kg · Current: ${fmt(d.total,1)} kg.</p>`;
  }else{
    host.innerHTML=`<strong>Tracking started: ${key}</strong><p>Your current estimate (${fmt(d.total,1)} kg CO₂e/person/month) is saved on this device. Come back next month to see a month-to-month comparison. This is a saved estimate, not measured meter data.</p>`;
  }
  history[key]={total:d.total,updatedAt:new Date().toISOString()};
  try{localStorage.setItem(HISTORY_KEY,JSON.stringify(history));}catch(e){}
}

function applianceScenarioKey(a){
  return `${a.name}|${a.watts}|${a.qty}`;
}
function renderApplianceScenarioControls(){
  const host = $("sim-appliance-controls");
  if(!host) return;
  if(!appliances.length){
    host.innerHTML = "<p class='helper-note'>Add appliances in the Energy Audit to compare their usage here.</p>";
    return;
  }
  host.innerHTML = appliances.map((a,i)=>{
    const key = applianceScenarioKey(a);
    const reduction = clamp(Number(applianceReductions[key] || 0),0,a.hours);
    applianceReductions[key] = reduction;
    return `<div class="sim-control sim-appliance-control">
      <div class="sim-control-head"><label for="sim-appliance-${i}">${escapeHtml(a.name)}</label><strong><span id="sim-appliance-value-${i}">${fmt(reduction,1)}</span> hour/day less</strong></div>
      <input type="range" id="sim-appliance-${i}" min="0" max="${Math.max(a.hours,0.5)}" step="0.5" value="${reduction}" data-sim-appliance="${i}" ${a.hours<=0?"disabled":""} aria-label="Reduce ${escapeHtml(a.name)} usage">
      <div class="range-labels"><span>No change</span><span>Current: ${fmt(a.hours,1)} h/day</span></div>
      <small>${a.watts} W · ${a.qty} unit(s) · ${fmt(energyFor(a),1)} kWh/month currently</small>
    </div>`;
  }).join("");
}
function getScenario(){
  if(!current) current=readInputs();
  const d=current;
  let electricitySaving=0;
  let billSaving=0;
  appliances.forEach(a=>{
    const reduction=clamp(Number(applianceReductions[applianceScenarioKey(a)] || 0),0,a.hours);
    const savedKwh=a.watts*reduction*30*a.qty/1000;
    electricitySaving += savedKwh*0.7/d.people;
    billSaving += savedKwh*d.tariff;
  });
  const commuteChoice=$("sim-commute").value;
  const newCommuteFactor=commuteChoice==="same" ? commuteFactor() : Number(commuteChoice);
  const newCommute=newCommuteFactor*safeNumber("commute-km")*30;
  const dietChoice=$("sim-diet").value;
  const newDiet=dietChoice==="same" ? d.diet : Number(dietChoice);
  const newElectricity=Math.max(0,d.electricityPerPerson-electricitySaving);
  const categories=[newCommute,newElectricity,newDiet,d.flights,d.waste];
  const total=categories.reduce((a,b)=>a+b,0);
  return {categories,total,saving:Math.max(0,d.total-total),billSaving};
}
function renderScenario(){
  if(!current)return;
  const s=getScenario();
  const d=current;
  $("sim-current").textContent=Math.round(d.total).toLocaleString("en-IN");
  $("sim-new").textContent=Math.round(s.total).toLocaleString("en-IN");
  $("sim-saving").textContent=`${fmt(s.saving,1)} kg`;
  $("sim-saving-percent").textContent=`${d.total>0?fmt(s.saving/d.total*100,1):"0"}% lower than current footprint`;
  $("sim-money-saving").textContent=`${money(s.billSaving)} / month`;
  $("sim-current-label").textContent=`${fmt(d.total,1)} kg`;
  $("sim-new-label").textContent=`${fmt(s.total,1)} kg`;
  const max=Math.max(d.total,s.total,1);
  $("sim-current-bar").style.width=`${d.total/max*100}%`;
  $("sim-new-bar").style.width=`${s.total/max*100}%`;
}

function save(){
  const state={appliances,inputs:{}};
  ["commute-mode","vehicle-type","commute-km","diet","flights","waste","people","tariff"].forEach(id=>state.inputs[id]=$(id).value);
  state.inputs.standby=$("standby").checked;
  try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}catch(e){}
}
function load(){
  try{
    const state=JSON.parse(localStorage.getItem(STORAGE_KEY)||"null");
    if(!state)return;
    if(Array.isArray(state.appliances)) appliances=state.appliances.filter(a=>a&&typeof a.name==="string"&&Number(a.watts)>0).map(a=>({name:a.name,watts:Number(a.watts),hours:clamp(Number(a.hours)||0,0,24),qty:clamp(Math.floor(Number(a.qty)||1),1,50)}));
    if(state.inputs) Object.entries(state.inputs).forEach(([id,value])=>{if($(id)){if(id==="standby")$(id).checked=!!value;else $(id).value=value;}});
  }catch(e){}
}
function resetAll(){
  if(!confirm("Reset appliance and lifestyle inputs to the CarbonCut defaults?"))return;
  appliances=DEFAULT_APPLIANCES.map(x=>({...x}));
  $("commute-mode").value="motorcycle";$("vehicle-type").value="bike_petrol_150";$("commute-km").value=10;updateVehicleOptions();$("diet").value=90;$("flights").value=2;$("waste").value=15;$("people").value=1;$("tariff").value=7;$("standby").checked=false;
  applianceReductions={};$("sim-commute").value="same";$("sim-diet").value="same";
  renderAppliances();update();
}
function showPage(name){
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===`page-${name}`));
  document.querySelectorAll(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.page===name));
  const headings={dashboard:"Your carbon dashboard",audit:"Energy audit",simulator:"What-if simulator"};
  $("page-heading").textContent=headings[name]||headings.dashboard;
  window.scrollTo({top:0,behavior:"smooth"});
  if(name==="simulator")renderScenario();
}
document.addEventListener("click",e=>{
  const nav=e.target.closest(".nav-link[data-page]");
  const go=e.target.closest("[data-go]");
  if(nav) showPage(nav.dataset.page);
  else if(go) showPage(go.dataset.go);
});
$("appliance-list").addEventListener("input",e=>{
  if(e.target.matches("[data-hours]")){const i=Number(e.target.dataset.hours);appliances[i].hours=Number(e.target.value);e.target.closest(".appliance-row").querySelector(".usage-number").textContent=`${fmt(appliances[i].hours,1)} h/day`;update();}
});
$("appliance-list").addEventListener("click",e=>{
  const b=e.target.closest("[data-remove]");if(!b)return;
  appliances.splice(Number(b.dataset.remove),1);renderAppliances();update();
});
$("show-add").addEventListener("click",()=>{$("add-form").classList.remove("hidden");$("new-name").focus();});
$("cancel-add").addEventListener("click",()=>{$("add-form").classList.add("hidden");$("add-form").reset();});
$("add-form").addEventListener("submit",e=>{
  e.preventDefault();
  const name=$("new-name").value.trim(),watts=Number($("new-watts").value),hours=Number($("new-hours").value),qty=Number($("new-quantity").value);
  if(!name||watts<=0||hours<0||hours>24||qty<1){alert("Please enter valid appliance details.");return;}
  appliances.push({name,watts,hours,qty});renderAppliances();$("add-form").reset();$("new-hours").value=2;$("new-quantity").value=1;$("add-form").classList.add("hidden");update();
});
["commute-mode","vehicle-type","commute-km","diet","flights","waste","people","tariff","standby"].forEach(id=>$(id).addEventListener("input",()=>{if(id==="commute-mode")updateVehicleOptions();update();}));
$("sim-appliance-controls").addEventListener("input",e=>{
  if(e.target.matches("[data-sim-appliance]")){
    const i=Number(e.target.dataset.simAppliance);
    const a=appliances[i];
    if(!a)return;
    const reduction=Number(e.target.value);
    applianceReductions[applianceScenarioKey(a)]=reduction;
    const value=$("sim-appliance-value-"+i);
    if(value)value.textContent=fmt(reduction,1);
    renderScenario();
    renderAchievements(current);
  }
});
["sim-commute","sim-diet"].forEach(id=>$(id).addEventListener("input",()=>{renderScenario();renderAchievements(current);}));
$("reset-sim").addEventListener("click",()=>{applianceReductions={};$("sim-commute").value="same";$("sim-diet").value="same";renderScenario();renderAchievements(current);});
$("reset-button").addEventListener("click",resetAll);
$("print-report").addEventListener("click",()=>{ update(); window.print(); });
load();updateVehicleOptions();renderAppliances();update();
